\echo Use "CREATE EXTENSION aidb" to load this file. \quit

CREATE SCHEMA aidb;

-- Some models (esp. in HuggingFace)
-- don't produce normalized
-- embedding vectors, so we can't
-- use cosine distance on them.
-- Including euclidean for
-- completeness. Note that when
-- pgvector says negative inner
-- product they mean dot product.
CREATE TYPE distance_metric AS ENUM (
    'cosine',
    'dot',
    'euclidean'
);

CREATE TYPE data_sources AS ENUM (
    'pg',
    's3'
);

CREATE TYPE data_types AS ENUM(
    'img',
    'text'

);

CREATE OR REPLACE FUNCTION aidb.init() RETURNS VOID AS
$$
    import sys
    if 'aidb' not in sys.modules:
        import os
        path = '{}/lib/python{}.{}/site-packages'.format(
            os.environ.get('VIRTUAL_ENV', ''),
            sys.version_info.major,
            sys.version_info.minor
        )
        sys.path.append(path)
        import aidb
        aidb.init(GD)
$$ LANGUAGE plpython3u;


CREATE OR REPLACE FUNCTION aidb.create_pg_retriever(
    retriever_name text,
    s text, -- schema
    primary_key text,
    encoder text,
    data_type data_types,
    tab text, -- table
    columns text[],
    auto_embedding boolean default TRUE,
    distance_metric distance_metric default NULL
) RETURNS text AS
$$
    import sys
    import os
    path = '{}/lib/python{}.{}/site-packages'.format(
            os.environ.get('VIRTUAL_ENV', ''),
            sys.version_info.major,
            sys.version_info.minor
        )
    sys.path.append(path)
    if 'aidb' not in sys.modules:
        plpy.execute('SELECT aidb.init();')
    import aidb
    create_retriever = aidb.Create_Retriever(GD, retriever_name, s, encoder, data_type, distance_metric)
    return create_retriever.create_pg_retriever(primary_key, auto_embedding, tab, columns)
$$ LANGUAGE plpython3u;

CREATE OR REPLACE FUNCTION aidb.create_s3_retriever(
    retriever_name text,
    s text, -- schema
    encoder text,
    data_type data_types,
    bucket text,
    prefix text,
    s3_endpoint text default NULL,
    distance_metric distance_metric default NULL
) RETURNS text AS
$$
    import sys
    import os
    path = '{}/lib/python{}.{}/site-packages'.format(
            os.environ.get('VIRTUAL_ENV', ''),
            sys.version_info.major,
            sys.version_info.minor
        )
    sys.path.append(path)
    if 'aidb' not in sys.modules:
        plpy.execute('SELECT aidb.init();')
    import aidb
    create_retriever = aidb.Create_Retriever(GD, retriever_name, s, encoder, data_type, distance_metric)
    return create_retriever.create_s3_retriever(s3_endpoint, bucket, prefix)
$$ LANGUAGE plpython3u;

CREATE OR REPLACE FUNCTION aidb._embed_table_update(
    retriever_name text,
    ids text[],
    inputs text[]
) RETURNS VOID AS
$$
    import sys
    if 'aidb' not in sys.modules:
        plpy.execute('SELECT aidb.init();')
    import aidb
    return aidb._embed_table_update(retriever_name, ids, inputs)
$$ LANGUAGE plpython3u;

--- This is the batch embedding function
CREATE OR REPLACE FUNCTION aidb.refresh_retriever(
    retriever_name text
) RETURNS VOID AS
$$
    import sys
    if 'aidb' not in sys.modules:
        plpy.execute('SELECT aidb.init();')
    import aidb
    return aidb.refresh_retriever(retriever_name)
$$ LANGUAGE plpython3u;

CREATE OR REPLACE FUNCTION aidb.retrieve(
    query text,    -- The query text for which to retrieve the top similar data
    topk int,         -- Number of most similar records to retrieve
    retriever_name text
) RETURNS TABLE (data text) AS
$$
    import sys
    if 'aidb' not in sys.modules:
        plpy.execute('SELECT aidb.init();')
    import aidb
    return aidb.retrieve(query, topk, retriever_name)
$$ LANGUAGE plpython3u;

CREATE OR REPLACE FUNCTION aidb.retrieve_via_s3(
    retriever_name text,
    topk int,         -- Number of most similar records to retrieve
    bucket text,
    object text default NULL,
    s3_endpoint text default NULL
) RETURNS TABLE (data text) AS
$$
    import sys
    if 'aidb' not in sys.modules:
        plpy.execute('SELECT aidb.init();')
    import aidb
    return aidb.retrieve_via_s3(retriever_name, topk, s3_endpoint, bucket, object)
$$ LANGUAGE plpython3u;

-- Registers a prompt template with
-- aidb. The prompt can later be
-- referenced by name in other aidb
-- functions.
--
-- In the future, prompts should /
-- will store metadata regarding
-- their usage, etc.
CREATE OR REPLACE FUNCTION aidb.register_prompt_template(
    template_name text, -- TODO: Could just use the ID here?
    template text -- Templates use jinja2 syntax
) RETURNS VOID AS
$$
    import sys
    if 'aidb' not in sys.modules:
        plpy.execute('SELECT aidb.init();')
    import aidb
    aidb.register_prompt_template(template_name, template)
$$ LANGUAGE plpython3u;

-- Given a prompt name and a JSON
-- "environment", render the prompt
-- template using jinja2. The user
-- can inject anything they want
-- into the environment.
CREATE OR REPLACE FUNCTION aidb.render_prompt(
    template_name text, -- The name of a prompt template previously registered
    env jsonb -- Use jsonb_build_object to construct this with subqueries, etc.
) RETURNS TEXT AS
$$
    import sys
    if 'aidb' not in sys.modules:
        plpy.execute('SELECT aidb.init();')
    import aidb
    return aidb.render_prompt(template_name, env)
$$ LANGUAGE plpython3u;

-- Execute a completion given a
-- prompt and model, e.g.,
-- gpt-3.5-turbo.
--
-- TODO: support model parameters,
-- e.g., temperature.
CREATE OR REPLACE FUNCTION aidb.generate(
    prompt text, -- Note that this is a /prompt/, not a template
    model text -- TODO: store model metadata
) RETURNS TEXT AS
$$
    import sys
    if 'aidb' not in sys.modules:
        plpy.execute('SELECT aidb.init();')
    import aidb
    return aidb.generate(prompt, model)
$$ LANGUAGE plpython3u;

-- Given a prompt template name and
-- a rendering environment, render
-- the prompt and send it to
-- aidb.generate for completion.
--
-- Note that this is called `ag` in
-- the sense that it's RAG without
-- the retrieval - in this case, we
-- assume that the retrieval was
-- done by the caller.
CREATE OR REPLACE FUNCTION aidb.ag(
    prompt_name text,
    env jsonb,
    model text
) RETURNS TEXT AS
$$
    import sys
    if 'aidb' not in sys.modules:
        plpy.execute('SELECT aidb.init();')
    import aidb
    return aidb.ag(prompt_name, env, model)
$$ LANGUAGE plpython3u;

-- `aidb.rag() ` implements a full
-- RAG pipeline, from a user query
-- to completion. This function will
-- automatically perform an ANN
-- search for the user prompt in the
-- specified retriever and add that
-- to the user-supplied `env`.
--
-- Note that `query` and `retrieved`
-- are "special" template variables
-- that will /always/ be injected
-- into `env` when called via
-- `aidb.rag`, regardless of whether
-- or not there are existing keys
-- with those values.
CREATE OR REPLACE FUNCTION aidb.rag(
    query text,
    retriever_name text,
    topk int,
    prompt_name text,
    env jsonb,
    model text
) RETURNS TEXT AS
$$
    import sys
    if 'aidb' not in sys.modules:
        plpy.execute('SELECT aidb.init();')
    import aidb
    return aidb.rag(query, retriever_name, topk, prompt_name, env, model)
$$ LANGUAGE plpython3u;

CREATE TABLE aidb.prompt_templates (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    template TEXT NOT NULL,
    args TEXT[]
);

CREATE TYPE model_provider AS ENUM (
    'openai',
    'huggingface'
);

-- TODO: How to support "flexible"
-- embedding sizes that new models
-- like text-embedding-3-large
-- support?
CREATE TABLE IF NOT EXISTS aidb.encoders (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    provider model_provider NOT NULL,
    max_tokens INTEGER,
    default_distance_metric distance_metric NOT NULL,
    dimensions INTEGER NOT NULL
);

DELETE FROM aidb.encoders;
INSERT INTO aidb.encoders (name, provider, max_tokens, default_distance_metric, dimensions) VALUES
('text-embedding-ada-002', 'openai', 8191, 'cosine', 1536),
('text-embedding-3-small', 'openai', 8191, 'cosine', 1536),
('text-embedding-3-large', 'openai', 8191, 'cosine', 2000), -- Actually 3072, but HNSW in pgvector can only do 2000
('clip-vit-base-patch32', 'openai', 512, 'cosine', 512), -- Fore more information, please visit https://huggingface.co/docs/transformers/model_doc/clip
-- Only the "recommended" models from HF are included:
-- https://www.sbert.net/docs/pretrained_models.html
-- TODO: Dynamic models from HF
-- TODO: FDW to HF tables?
-- Sentence-Transformer Models
('gtr-t5-xxl'                            , 'huggingface', 512, 'dot', 768),
('gtr-t5-xl'                             , 'huggingface', 512, 'dot', 768),
('sentence-t5-xxl'                       , 'huggingface', 256, 'dot', 768),
('gtr-t5-large'                          , 'huggingface', 512, 'dot', 768),
('all-mpnet-base-v1'                     , 'huggingface', 512, 'dot', 768),
('multi-qa-mpnet-base-cos-v1'            , 'huggingface', 512, 'dot', 768),
('all-roberta-large-v1'                  , 'huggingface', 256, 'dot', 1024),
('sentence-t5-xl'                        , 'huggingface', 256, 'dot', 768),
('all-MiniLM-L12-v1'                     , 'huggingface', 256, 'dot', 384),
('gtr-t5-base'                           , 'huggingface', 512, 'dot', 768),
('sentence-t5-large'                     , 'huggingface', 256, 'dot', 768),
('all-MiniLM-L6-v1'                      , 'huggingface', 256, 'dot', 384),
('msmarco-bert-base-dot-v5'              , 'huggingface', 512, 'dot', 768),
('multi-qa-MiniLM-L6-dot-v1'             , 'huggingface', 512, 'dot', 384),
('sentence-t5-base'                      , 'huggingface', 256, 'dot', 768),
('msmarco-distilbert-base-tas-b'         , 'huggingface', 512, 'dot', 768),
('msmarco-distilbert-dot-v5'             , 'huggingface', 512, 'dot', 768),
('multi-qa-mpnet-base-dot-v1'            , 'huggingface', 512, 'dot', 384),
('multi-qa-distilbert-dot-v1'            , 'huggingface', 512, 'dot', 768),
('paraphrase-MiniLM-L6-v2'               , 'huggingface', 128, 'cosine', 384),
('paraphrase-TinyBERT-L6-v2'             , 'huggingface', 128, 'cosine', 768),
('paraphrase-MiniLM-L12-v2'              , 'huggingface', 256, 'cosine', 384),
('paraphrase-distilroberta-base-v2'      , 'huggingface', 256, 'cosine', 768),
('paraphrase-mpnet-base-v2'              , 'huggingface', 512, 'cosine', 768),
('all-mpnet-base-v2'                     , 'huggingface', 384, 'cosine', 768),
('all-distilroberta-v1'                  , 'huggingface', 512, 'cosine', 768),
('all-MiniLM-L12-v2'                     , 'huggingface', 256, 'cosine', 384),
('multi-qa-distilbert-cos-v1'            , 'huggingface', 512, 'cosine', 768),
('all-MiniLM-L6-v2'                      , 'huggingface', 256, 'cosine', 384),
('multi-qa-MiniLM-L6-cos-v1'             , 'huggingface', 512, 'cosine', 384),
('paraphrase-multilingual-mpnet-base-v2' , 'huggingface', 128, 'cosine', 768),
('paraphrase-albert-small-v2'            , 'huggingface', 256, 'cosine', 768),
('paraphrase-multilingual-MiniLM-L12-v2' , 'huggingface', 128, 'cosine', 384),
('paraphrase-MiniLM-L3-v2'               , 'huggingface', 128, 'cosine', 384),
('distiluse-base-multilingual-cased-v1'  , 'huggingface', 128, 'cosine', 512),
('distiluse-base-multilingual-cased-v2'  , 'huggingface', 128, 'cosine', 512);

-- TODO: Figure out an upgrade path
CREATE TABLE IF NOT EXISTS aidb.retrievers (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    creator TEXT,
    created TIMESTAMP,
    source_schema TEXT NOT NULL,
    source_table TEXT NULL,
    source_columns TEXT NULL,
    source_key TEXT NOT NULL,
    source_key_type TEXT NOT NULL,
    auto_embedding BOOLEAN NOT NULL,
    distance_metric distance_metric NOT NULL,
    ef_construction INT NOT NULL,
    m INT NOT NULL,
    ef_search INT NOT NULL,
    embedding_table TEXT NOT NULL,
    encoder_id INTEGER NOT NULL,
    s3_endpoint TEXT NULL,
    bucket TEXT NULL,
    prefix TEXT NULL,
    tag TEXT NULL,
    data_sources data_sources NOT NULL,
    data_type data_types NOT NULL,
    FOREIGN KEY (encoder_id) REFERENCES aidb.encoders (id)
);

CREATE TABLE aidb.example (
    character_id SERIAL PRIMARY KEY,
    character_name TEXT NOT NULL,
    description TEXT,
    last_updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO aidb.example(character_name, description, last_updated_at) VALUES
('Tony Stark', 'Genius, billionaire, playboy, philanthropist, and Iron Man.', now()),
('Luke Skywalker', 'Skilled Jedi Knight who fought against the Galactic Empire.', now()),
('Hermione Granger', 'Brilliant and resourceful witch from the Harry Potter series.', now()),
('Indiana Jones', 'Archaeologist and adventurer known for his whip and fedora.', now()),
('Ellen Ripley', 'Courageous and resourceful warrant officer from the Alien franchise.', now()),
('James Bond', 'Suave and skilled MI6 agent with a preference for martinis.', now()),
('Sarah Connor', 'Fearless mother of John Connor and fighter against Skynet.', now()),
('Katniss Everdeen', 'Brave and skilled archer from the Hunger Games series.', now()),
('Darth Vader', 'Powerful Sith Lord and former Jedi Knight Anakin Skywalker.', now()),
('Neo', 'The chosen one who fights against the Matrix in the film series.', now()),
('Marty McFly', 'Teenager who time travels in a DeLorean in Back to the Future.', now()),
('Elsa', 'Ice queen with magical powers from the Disney movie Frozen.', now()),
('Jack Sparrow', 'Witty and resourceful pirate captain in the Pirates of the Caribbean series.', now()),
('Trinity', 'Skilled hacker and fighter helping Neo in the Matrix trilogy.', now()),
('Rocky Balboa', 'Underdog boxer who becomes a champion in the Rocky films.', now()),
('Katniss Everdeen', 'Brave and skilled archer from the Hunger Games series.', now()),
('Frodo Baggins', 'Hobbit tasked with destroying the One Ring in The Lord of the Rings.', now()),
('John Wick', 'Master assassin seeking revenge in the John Wick series.', now()),
('Thor', 'God of Thunder and member of the Avengers in the Marvel Cinematic Universe.', now()),
('Bruce Wayne', 'Billionaire playboy who becomes Batman to fight crime in Gotham.', now()),
('James T. Kirk', 'Charismatic captain of the USS Enterprise in Star Trek.', now()),
('Lara Croft', 'Adventurous and skilled archaeologist from the Tomb Raider series.', now()),
('Rick Deckard', 'Blade Runner tasked with hunting down replicants in Blade Runner.', now()),
('Alice', 'Courageous survivor in the Resident Evil film series.', now()),
('Captain Jack Harkness', 'Time-traveling adventurer from Doctor Who and Torchwood.', now()),
('Morpheus', 'Mentor who frees Neo and fights the machines in The Matrix.', now()),
('Wolverine (Logan)', 'Mutant with regenerative powers and adamantium claws in X-Men.', now()),
('Jason Bourne', 'Amnesiac secret agent with exceptional combat skills in the Bourne series.', now()),
('Ferris Bueller', 'Charismatic high school student who takes a day off in Ferris Bueller''s Day Off.', now()),
('Samwise Gamgee', 'Loyal friend and companion to Frodo in The Lord of the Rings.', now()),
('Ethan Hunt', 'Skilled IMF agent leading high-stakes missions in Mission: Impossible.', now()),
('Ripley', 'A warrant officer who battles xenomorphs in the Alien series.', now()),
('John McClane', 'Tough and resourceful NYPD officer in the Die Hard films.', now()),
('Vito Corleone', 'Powerful mafia boss in The Godfather, known for his code of honor.', now()),
('Forrest Gump', 'Simple-minded yet kind-hearted man who lives through pivotal moments in history.', now()),
('The Dude (Jeff Lebowski)', 'Chill and laid-back protagonist of The Big Lebowski.', now()),
('Eve Harrington', 'Ambitious and conniving character in All About Eve.', now());

--- Initial function to generate Text Embedding - will be updated
CREATE OR REPLACE FUNCTION aidb.generate_text_embedding(
    model_name TEXT,
    model_provider TEXT,
    dimensions INT,
    text_to_encode TEXT
 
) RETURNS float[] AS
$$
    import sys
    import os
    path = '{}/lib/python{}.{}/site-packages'.format(
            os.environ.get('VIRTUAL_ENV', ''),
            sys.version_info.major,
            sys.version_info.minor
        )
    sys.path.append(path)
    import numpy as np
    if 'aidb' not in sys.modules:
        plpy.execute("SELECT aidb.init();")
    import aidb
    embeddings= aidb.TextEmbedder(model_name, model_provider, GD, dimensions).generate_text_embedding(text_to_encode)
    ret = np.asarray(embeddings, dtype=np.float32).tolist()
    return ret
$$ LANGUAGE plpython3u;

--- Initial function to generate Text Embedding - will be updated
CREATE OR REPLACE FUNCTION aidb.generate_single_image_embedding(
    model_name TEXT,
    model_provider TEXT,
    s3_endpoint TEXT,
    bucket TEXT,
    prefix TEXT,
    tag TEXT default NULL

) RETURNS float[] AS
$$
    import sys
    import os
    path = '{}/lib/python{}.{}/site-packages'.format(
            os.environ.get('VIRTUAL_ENV', ''),
            sys.version_info.major,
            sys.version_info.minor
        )
    sys.path.append(path)
    import numpy as np
    if 'aidb' not in sys.modules:
        plpy.execute("SELECT aidb.init();")
    import aidb
    image_embedder = aidb.ImageEmbedder(model_name, model_provider, GD, s3_endpoint, bucket, prefix, tag)
    embeddings = image_embedder.generate_single_image_embedding()
    ret = np.asarray(embeddings, dtype=np.float32).tolist()
    return ret
$$ LANGUAGE plpython3u;

