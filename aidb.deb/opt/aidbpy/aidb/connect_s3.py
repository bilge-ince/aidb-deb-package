import os
import boto3
import logging


from botocore.handlers import disable_signing


class S3_Connection:
    def __init__(self, GD: dict, s3_endpoint: str):
        self.GD = GD
        self.s3_endpoint = s3_endpoint
        self.log = logging.getLogger(__name__)
        if not (self.GD.get("hmac_access_key") or self.GD.get("hmac_secret_key")):
            self.GD["hmac_access_key"] = (
                os.getenv("ACCESS_KEY") if os.getenv("ACCESS_KEY") else None
            )
            self.GD["hmac_secret_key"] = (
                os.getenv("SECRET_KEY") if os.getenv("SECRET_KEY") else None
            )

    def create_s3_client(self):
        if self.s3_endpoint:
            s3 = boto3.resource(
                service_name="s3",
                endpoint_url=self.s3_endpoint,
            )
            s3.meta.client.meta.events.register("choose-signer.s3.*", disable_signing)
            return s3
        elif self.GD.get("hmac_access_key") or self.GD.get("hmac_secret_key"):
            return boto3.resource(
                service_name="s3",
                aws_access_key_id=self.GD.get("hmac_access_key"),
                aws_secret_access_key=self.GD.get("hmac_secret_key"),
            )
        else:
            self.log.error("No s3 sign in parameter has been found")
            raise Exception("No s3 sign in parameter has been found")
