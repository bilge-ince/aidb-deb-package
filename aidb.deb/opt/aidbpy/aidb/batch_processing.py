import logging
import numpy as np
import concurrent.futures

from aidb.generate_embeddings import TextEmbedder
from typing import List


class DataProcessor:
    def __init__(
        self,
        data: List[str],
        batch_size: int,
        model_name: str,
        provider: str,
        GD: dict,
        dimensions: int = None,
    ):
        """
        Initialize the DataProcessor with data, batch size, and a TextEmbedder object.

        Args:
        - data: List of input texts.
        - batch_size: Size of each batch.
        - text_embedder: An instance of the TextEmbedder class.
        """
        self.data = data
        self.batch_size = batch_size
        self.model_name = model_name
        self.provider = provider
        self.GD = GD
        self.dimensions = dimensions
        self.max_workers = 2
        self.log = logging.getLogger(__name__)

    # TODO : Make parallel calls for batches
    def process_data(self) -> np.array:
        """
        Process data in batches and generate embeddings.

        Returns:
        - embeddings: List of embeddings generated from input texts.
        """
        embeddings = []
        embedding_ids = []

        batches = [
            (self.data[i : i + self.batch_size], range(i, i + self.batch_size))
            for i in range(0, len(self.data), self.batch_size)
        ]

        with concurrent.futures.ThreadPoolExecutor(
            max_workers=self.max_workers
        ) as executor:

            # Submit batches for processing
            future_to_batch = {
                executor.submit(
                    TextEmbedder(
                        self.model_name, self.provider, self.GD, self.dimensions
                    ).generate_text_embedding,
                    batch,
                ): (batch, batch_ids)
                for batch, batch_ids in batches
            }

            # Retrieve results as they become available
            for future in concurrent.futures.as_completed(future_to_batch):
                batch, batch_ids = future_to_batch[future]
                try:
                    batch_embeddings = future.result()
                    assert len(batch_embeddings) == len(
                        batch_ids
                    ), "Mismatch between number of embeddings and IDs"
                    embeddings.extend(batch_embeddings)
                    embedding_ids.extend(batch_ids)
                except Exception as e:
                    self.log.error(f"Error processing batch: {batch}, {e}")
                    raise ValueError(f"Error processing batch: {batch}, {e}")
        # Convert embeddings and IDs to numpy arrays
        embeddings = np.array(embeddings)
        embedding_ids = np.array(embedding_ids)

        # Sort the embeddings by their IDs
        sorted_indices = np.argsort(embedding_ids)
        sorted_embeddings = embeddings[sorted_indices]
        return sorted_embeddings
