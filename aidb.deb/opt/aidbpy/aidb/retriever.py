from aidb.connect_s3 import S3_Connection
from enum import Enum

import plpy
import logging


class data_sources(Enum):
    PG = "pg"
    S3 = "s3"


class Create_Retriever:
    def __init__(
        self,
        GD,
        retriever_name,
        schema,
        encoder,
        data_type,
        distance_metric=None,
    ):
        self.GD = GD
        self.retriever_name = retriever_name
        self.schema = schema
        self.encoder = encoder
        self.distance_metric = distance_metric
        self.data_type = data_type
        self.pgvector_distance = {
            "cosine": {"operator_class": "vector_cosine_ops", "operator": "<=>"},
            "dot": {"operator_class": "vector_ip_ops", "operator": "<#>"},
            "euclidean": {"operator_class": "vector_l2_ops", "operator": "<->"},
        }
        self.log = logging.getLogger(__name__)
        
        self.retriever_data = plpy.execute(f"SELECT name from aidb.retrievers where name = '{self.retriever_name}';")

    def create_s3_retriever(self, s3_endpoint, bucket, prefix):
        """
        This function is the early release implementation for S3 bucket retriever creation that is going to use the files in S3 bucket to generate embeddings.
        It assumes for user have had created and prepared the data already.
        The filename is going to be used as unique id for embedding table, therefore no need to have another source table.
        Moreover, this will be available only in Bulk Mode.
        """
        if self.retriever_data:
            plpy.error("The name you entered for the retriever is already in use. Please choose a different name.")
            self.log.warning("The name you entered for the retriever is already in use. Please choose a different name.")
            return None
        # Connect s3_client to AWS for further use
        s3_client = S3_Connection(self.GD, s3_endpoint).create_s3_client()
        self.GD["s3_client"] = s3_client
        # use case is considered as img initially therefore s3 bucket file_name will be the primary key
        # for embeddings table

        primary_key_type = "TEXT"
        primary_key = f"{self.data_type.lower()}_id"
        # Validate encoder model and get dimensions
        encoder_data = plpy.execute(
            """
                SELECT id, dimensions, default_distance_metric
                FROM aidb.encoders
                WHERE name = '{encoder}';
            """.format(
                encoder=self.encoder
            )
        )
        if len(encoder_data) == 0:
            self.log.error(
                "Encoder model '{}' is not supported by aidb.".format(self.encoder)
            )
            raise Exception(
                "Encoder model '{}' is not supported by aidb.".format(self.encoder)
            )

        vector_size = encoder_data[0]["dimensions"]
        encoder_id = encoder_data[0]["id"]

        if self.distance_metric is None:
            self.distance_metric = encoder_data[0]["default_distance_metric"]

        vector_type = "vector({})".format(vector_size)
        table_name = "_aidb_embeddings_{}".format(self.retriever_name)

        # Todo Allow app to override these defaults
        ef_construction = 64
        m = 16
        ef_search = 40
        self.schema = plpy.quote_ident(self.schema)
        table_name = plpy.quote_ident(table_name)
        self.retriever_name = plpy.quote_ident(self.retriever_name)
        distance_operator = self.pgvector_distance[self.distance_metric][
            "operator_class"
        ]

        # Initial tables, index, view, and function creation
        embedding_setup = f"""
            CREATE TABLE IF NOT EXISTS {self.schema}.{table_name} (
                {primary_key} {primary_key_type} UNIQUE NOT NULL,
                embeddings {vector_type} NOT NULL,
                updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL);
            COMMENT ON TABLE {self.schema}.{table_name} IS
            'This table stores embeddings automatically computed by aidb.';

            CREATE INDEX IF NOT EXISTS {self.retriever_name}_idx
                ON {self.schema}.{table_name}
                USING hnsw (embeddings {distance_operator});
            COMMENT ON INDEX {self.retriever_name}_idx IS
                'Automatically created by aidb.';

            -- Abstract away access to the embeddings via a view.
            CREATE OR REPLACE VIEW {self.schema}.{self.retriever_name} AS
                SELECT t1.embeddings, t1.updated_at AS embeddings_updated_at
                FROM {self.schema}.{table_name} t1;
            COMMENT ON VIEW {self.schema}.{self.retriever_name} IS
                'This view should be used to access embeddings computed by aidb.';

            -- Create functions for BULK embedding generation
            CREATE OR REPLACE FUNCTION {self.schema}.aidb_table_bulk_fun_{self.retriever_name}()
                RETURNS VOID AS $$
                BEGIN
                    PERFORM aidb.refresh_retriever(
                        '{self.retriever_name}'
                    );
                END $$ LANGUAGE plpgsql;
            COMMENT ON FUNCTION {self.schema}.aidb_table_bulk_fun_{self.retriever_name} IS
                'Automatically created by aidb.';
    
            """
        # Store the retriever meta data
        metadata_setup = """
        INSERT INTO aidb.retrievers (
        name, creator, created, source_schema, source_key, source_key_type, data_sources, data_type,
        auto_embedding, distance_metric , ef_construction , m , ef_search , embedding_table , encoder_id, s3_endpoint, bucket, prefix)
        VALUES (
        '{retriever_name}', CURRENT_USER, current_timestamp, '{source_schema}', '{source_key}', '{source_key_type}', '{data_sources}', '{data_type}', '{auto_embedding}', 
        '{distance_metric}', {ef_construction}, {m}, {ef_search}, '{embedding_table}', {encoder_id}, '{s3_endpoint}', '{bucket}', '{prefix}')
            """.format(
            # TODO: quoting is a mess here, figure it out later
            retriever_name=self.retriever_name,
            source_schema=self.schema,
            source_key=primary_key,
            source_key_type=primary_key_type,
            data_sources=data_sources.S3.value,
            data_type=self.data_type,
            auto_embedding=False,
            distance_metric=self.distance_metric,
            ef_construction=ef_construction,
            m=m,
            ef_search=ef_search,
            embedding_table=table_name,
            encoder_id=encoder_id,
            s3_endpoint=s3_endpoint,
            bucket=bucket,
            prefix=prefix,
        )
        # Concat main statement and meta statement into a single statement to execute all together at once.
        all_statements = embedding_setup + metadata_setup
        # TODO: Check err
        plpy.execute(all_statements)
        return None

    def create_pg_retriever(self, primary_key, auto_embedding, source_table, columns):
        """
        Generate necessary tables and functions for retriever.
        This function runs with pg source table as AI data to generate embeddings
        """
        if self.retriever_data:
            plpy.warning("The name you entered for the retriever is already in use. Please choose a different name.")
            self.log.warning("The name you entered for the retriever is already in use. Please choose a different name.")
            return None
        
        if self.data_type == "img":
            self.log.error("This function cannot be called with img data")
            raise ValueError("This function cannot be called with img data")
        rv = plpy.execute(
            """
            SELECT data_type
            FROM information_schema.columns
            WHERE
                table_schema = '{schema}'
                AND table_name = '{table}'
                AND column_name = '{primary_key}';
        """.format(
                schema=plpy.quote_ident(self.schema),
                table=plpy.quote_ident(source_table),
                primary_key=plpy.quote_ident(primary_key),
            )
        )
        primary_key_type = rv[0]["data_type"]

        encoder_data = plpy.execute(
            """
            SELECT id, dimensions, default_distance_metric
            FROM aidb.encoders
            WHERE name = '{encoder}';
        """.format(
                encoder=self.encoder
            )
        )
        if len(encoder_data) == 0:
            self.log.error(
                "Encoder model '{}' is not supporqted by aidb.".format(self.encoder)
            )
            raise Exception(
                "Encoder model '{}' is not supported by aidb.".format(self.encoder)
            )

        vector_size = encoder_data[0]["dimensions"]
        encoder_id = encoder_data[0]["id"]

        if self.distance_metric is None:
            self.distance_metric = encoder_data[0]["default_distance_metric"]

        vector_type = "vector({})".format(vector_size)

        table_name = "_aidb_embeddings_{}".format(self.retriever_name)

        # Todo Allow app to override these defaults
        ef_construction = 64
        m = 16
        ef_search = 40
        schema = plpy.quote_ident(self.schema)
        table_name = plpy.quote_ident(table_name)
        primary_key = plpy.quote_ident(primary_key)

        # this won't be exist if data is coming from S3
        source_table = plpy.quote_ident(source_table)
        retriever_name = plpy.quote_ident(self.retriever_name)
        # Comma-separated list of columns to be used to generate embeddings
        input_columns = ",".join([c for c in columns])
        distance_operator = self.pgvector_distance[self.distance_metric][
            "operator_class"
        ]
        # Bit of a hack here to get array appends done right in trigger functions
        # TODO: make sure this works with just a single column selected
        select_columns = "|| ' ' ||".join(["rec.{}".format(c) for c in columns])

        # Initial tables, index, view, and function creation
        embedding_setup = f"""
            CREATE TABLE IF NOT EXISTS {schema}.{table_name} (
                {primary_key} {primary_key_type} UNIQUE NOT NULL,
                embeddings {vector_type} NOT NULL,
                updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW() NOT NULL,
                FOREIGN KEY ({primary_key}) REFERENCES {schema}.{source_table} ({primary_key})
            ON DELETE CASCADE);
            COMMENT ON TABLE {schema}.{table_name} IS
            'This table stores embeddings automatically computed by aidb.';

            CREATE INDEX IF NOT EXISTS {retriever_name}_idx
                ON {schema}.{table_name}
                USING hnsw (embeddings {distance_operator});
            COMMENT ON INDEX {retriever_name}_idx IS
                'Automatically created by aidb.';

            -- Abstract away access to the embeddings via a view.
            CREATE OR REPLACE VIEW {schema}.{retriever_name} AS
                SELECT t0.*, t1.embeddings, t1.updated_at AS embeddings_updated_at
                FROM {schema}.{source_table} t0
                INNER JOIN {schema}.{table_name} t1
                ON t0.{primary_key} = t1.{primary_key};
            COMMENT ON VIEW {schema}.{retriever_name} IS
                'This view should be used to access embeddings computed by aidb.';

            -- Create functions for BULK embedding generation
            CREATE OR REPLACE FUNCTION {schema}.aidb_table_bulk_fun_{retriever_name}()
                RETURNS VOID AS $$
                BEGIN
                    PERFORM aidb.refresh_retriever(
                        '{retriever_name}'
                    );
                END $$ LANGUAGE plpgsql;
            COMMENT ON FUNCTION {schema}.aidb_table_bulk_fun_{retriever_name} IS
                'Automatically created by aidb.';
            """
        # The statement will be expended according to the passed processing option parameter
        embedding_trigger_setup = ""
        if auto_embedding:
            embedding_trigger_setup = f"""
            -- Create a function to serve as a trigger for new and updated rows in this table
            CREATE OR REPLACE FUNCTION {schema}._aidb_table_trigger_fun_{retriever_name}()
            RETURNS TRIGGER AS $$
            DECLARE
                ids TEXT[] := ARRAY[]::TEXT[];
                inputs TEXT[] := ARRAY[]::TEXT[];
                rec RECORD;
            BEGIN
                FOR rec in SELECT {primary_key} as p, {input_columns} FROM newtab LOOP
                    ids := array_append(ids, rec.p::text);
                    inputs := array_append(inputs, {select_columns});
                END LOOP;
                PERFORM aidb._embed_table_update(
                    '{retriever_name}',
                    ids,
                    inputs
                );
                RETURN NULL;
            END $$ LANGUAGE plpgsql;
            -- TODO
            COMMENT ON FUNCTION {schema}._aidb_table_trigger_fun_{retriever_name} IS
                'Automatically created by aidb.';

            -- Create a function to serve as a trigger for deleted rows in this table
            CREATE OR REPLACE FUNCTION {schema}._aidb_table_trigger_delete_fun_{retriever_name}()
            RETURNS TRIGGER AS $$
            DECLARE
                ids TEXT[] := ARRAY[]::TEXT[];
                rec RECORD;
            BEGIN
                FOR rec in SELECT {primary_key} as p FROM oldtab LOOP
                    ids := array_append(ids, rec.p::text);
                END LOOP;
                DELETE FROM {schema}._aidb_embeddings_{retriever_name} WHERE text({primary_key}) = ANY(ids);
                RETURN NULL;
            END $$ LANGUAGE plpgsql;
            -- TODO
            COMMENT ON FUNCTION {schema}._aidb_table_trigger_delete_fun_{retriever_name} IS
                'Automatically created by aidb.';

            -- Create the INSERT trigger
            CREATE TRIGGER _aidb_table_insert_trigger_{retriever_name}
                AFTER INSERT ON {schema}.{source_table}
                REFERENCING NEW TABLE AS newtab
                FOR EACH STATEMENT
                EXECUTE FUNCTION {schema}._aidb_table_trigger_fun_{retriever_name}();
            -- TODO
            COMMENT ON TRIGGER _aidb_table_insert_trigger_{retriever_name}
                ON {schema}.{source_table} IS
                'Automatically created by aidb.';

            -- Create the UPDATE trigger
            CREATE TRIGGER _aidb_table_update_trigger_{retriever_name}
                AFTER UPDATE ON {schema}.{source_table}
                REFERENCING NEW TABLE AS newtab
                FOR EACH STATEMENT
                EXECUTE FUNCTION {schema}._aidb_table_trigger_fun_{retriever_name}();
            -- TODO
            COMMENT ON TRIGGER _aidb_table_update_trigger_{retriever_name}
                ON {schema}.{source_table} IS
                'Automatically created by aidb.';

            -- Create the DELETE trigger
            CREATE TRIGGER _aidb_table_delete_trigger_{retriever_name}
                AFTER DELETE ON {schema}.{source_table}
                REFERENCING OLD TABLE AS oldtab
                FOR EACH STATEMENT
                EXECUTE FUNCTION {schema}._aidb_table_trigger_delete_fun_{retriever_name}();
            -- TODO
            COMMENT ON TRIGGER _aidb_table_delete_trigger_{retriever_name}
                ON {schema}.{source_table} IS
                'Automatically created by aidb.';
            """

        # Store the retriever meta data
        metadata_setup = """
        INSERT INTO aidb.retrievers (
        name, creator, created, source_schema, source_table, source_columns, source_key, data_sources, data_type, source_key_type,
        auto_embedding, distance_metric , ef_construction , m , ef_search , embedding_table , encoder_id)
        VALUES (
        '{retriever_name}', CURRENT_USER, current_timestamp, '{source_schema}', '{source_table}', '{source_columns}', '{source_key}', '{data_sources}', '{data_type}',
        '{source_key_type}', '{auto_embedding}', '{distance_metric}', {ef_construction}, {m}, {ef_search}, '{embedding_table}', {encoder_id})
            """.format(
            # TODO: quoting is a mess here, figure it out later
            retriever_name=self.retriever_name,
            source_schema=self.schema,
            source_table=source_table,
            source_columns=",".join(c for c in columns),
            source_key=primary_key,
            data_sources=data_sources.PG.value,
            data_type=self.data_type,
            source_key_type=primary_key_type,
            auto_embedding=auto_embedding,
            distance_metric=self.distance_metric,
            ef_construction=ef_construction,
            m=m,
            ef_search=ef_search,
            embedding_table=table_name,
            encoder_id=encoder_id,
        )
        # Concat main statement and meta statement into a single statement to execute all together at once.
        all_statements = embedding_setup + embedding_trigger_setup + metadata_setup
        # TODO: Check err
        plpy.execute(all_statements)
        return None
