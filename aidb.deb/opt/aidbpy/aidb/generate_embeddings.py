import numpy as np
import openai
import torch
import plpy
import logging

from botocore.handlers import disable_signing
from transformers import AutoTokenizer, AutoModel
from sentence_transformers import SentenceTransformer
from transformers import CLIPModel, CLIPProcessor
from aidb.connect_s3 import S3_Connection

from io import BytesIO
from PIL import Image


class ModelType:
    SentenceTransformer = "SentenceTransformer"
    AutoModel = "AutoModel"


class ImageEmbedder:
    def __init__(
        self,
        model_name: str,
        provider: str,
        GD: dict,
        s3_endpoint: str = None,
        bucket: str = None,
        object: str = None,
        tag: str = None,
    ):
        self.model_name = model_name
        self.provider = provider
        self.GD = GD
        self.s3_endpoint = s3_endpoint
        self.bucket = bucket
        self.object = object
        self.tag = tag
        self.log = logging.getLogger(__name__)

        if model_name not in ["clip-vit-base-patch32"] and provider not in ["openai"]:
            self.log.error(
                "Unsupported image embedding model {}/{}\n".format(provider, model_name)
            )
            raise ValueError(
                "Unsupported image embedding model {}/{}\n".format(provider, model_name)
            )

    def generate_single_image_embedding(self) -> np.array:

        s3 = self.GD.get("s3_client")
        if not s3:
            s3 = S3_Connection(self.GD, self.s3_endpoint).create_s3_client()
            self.GD["s3_client"] = s3
        # Cache OpenAI client in the GD dictionary
        client = self.GD.get("openai_client")
        if not client:
            client = openai.OpenAI()
            self.GD["openai_client"] = client

        model = self.GD.get("image_model/" + self.model_name)
        processor = self.GD.get("image_processor/" + self.model_name)
        if not (model and processor):
            model = CLIPModel.from_pretrained(self.provider + "/" + self.model_name)
            processor = CLIPProcessor.from_pretrained(
                self.provider + "/" + self.model_name
            )
            self.GD["image_model/" + self.model_name] = model
            self.GD["image_processor/" + self.model_name] = processor
        file_byte_string = s3.Object(self.bucket, self.object).get()["Body"].read()

        img = Image.open(BytesIO(file_byte_string))

        inputs = processor(
            text=[self.tag or self.object], images=img, return_tensors="pt"
        )
        outputs = model(**inputs)
        embedding = outputs.image_embeds
        return np.array(embedding.tolist(), dtype=np.float32)

    def generate_image_embeddings(self, image_inputs, input_names) -> np.array:

        s3 = self.GD.get("s3_client")

        # Cache OpenAI client in the GD dictionary
        client = self.GD.get("openai_client")
        if not client:
            client = openai.OpenAI()
            self.GD["openai_client"] = client

        model = self.GD.get("image_model/" + self.model_name)
        processor = self.GD.get("image_processor/" + self.model_name)
        if not (model and processor):
            model = CLIPModel.from_pretrained(self.provider + "/" + self.model_name)
            processor = CLIPProcessor.from_pretrained(
                self.provider + "/" + self.model_name
            )
            self.GD["image_model/" + self.model_name] = model
            self.GD["image_processor/" + self.model_name] = processor

        inputs = processor(text=input_names, images=image_inputs, return_tensors="pt", padding=True, truncation=True)
        outputs = model(**inputs)
        embeddings = outputs.image_embeds
        return embeddings.detach().numpy()


class TextEmbedder:
    def __init__(
        self, model_name: str, provider: str, GD: dict, dimensions: int = None
    ):
        self.model_name = model_name
        self.provider = provider
        self.model_type = self._detect_model_type()
        self.dimensions = dimensions
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.GD = GD

    def _detect_model_type(self):
        # Frequently used SentenceTransformer model names
        encoder_data = plpy.execute(
            f"""
            SELECT name
            FROM aidb.encoders
            WHERE LOWER(name) = '{self.model_name.lower()}' AND provider = '{self.provider.lower()}';
        """
        )
        # Assuming AutoModel if it's not a known SentenceTransformer model
        return ModelType.SentenceTransformer if encoder_data else ModelType.AutoModel

    def generate_text_embedding(self, texts) -> np.array:
        embeddings = None
        with torch.no_grad():
            if self.provider == "openai":
                # Cache OpenAI client in the GD dictionary
                client = self.GD.get("openai_client")
                if not client:
                    client = openai.OpenAI()
                    self.GD["openai_client"] = client

                if self.model_name == "text-embedding-3-large":
                    # OpenAI model text-embedding-3-large has up to 3072, but HNSW in pgvector maxes out at 2000
                    response = client.embeddings.create(
                        model=self.model_name, input=texts, dimensions=self.dimensions
                    )
                else:
                    # Old OpenAI embedding model API doesn't support to specify dimensions
                    response = client.embeddings.create(
                        model=self.model_name, input=texts
                    )
                # Extract embedding values from each object in embeddings_list
                embedding_values = [embedding.embedding for embedding in response.data]

                # Convert the list of embedding values to a NumPy ndarray
                # Ensure embeddings are of float32 type for pg_vector
                embeddings = np.array(embedding_values, dtype=np.float32)
            elif self.provider == "huggingface":
                if self.model_type == ModelType.AutoModel:
                    # Cache AutoModel in the GD dictionary
                    model = self.GD.get(self.model_name)
                    if not model:
                        try:
                            tokenizer = AutoTokenizer.from_pretrained(
                                self.model_name, local_files_only=True
                            )
                            model = AutoModel.from_pretrained(self.model_name)
                            self.GD[self.model_name] = model
                        except Exception as e:
                            self.log.error(
                                "Unsupported model {}\n{}".format(self.model_name, e)
                            )
                            raise ValueError(
                                "Unsupported model {}\n{}".format(self.model_name, e)
                            )
                    model.to(self.device)
                    # Using transformers for token-level embeddings
                    inputs = tokenizer(
                        texts, padding=True, truncation=True, return_tensors="pt"
                    ).to(self.device)
                    outputs = model(**inputs)
                    # Extract the embeddings from the last layer
                    embeddings = outputs.last_hidden_state.mean(dim=1)
                    embeddings = embeddings.cpu().detach().numpy()
                elif self.model_type == ModelType.SentenceTransformer:
                    # Cache HuggingFace client in the GD dictionary
                    model = self.GD.get(self.model_name)
                    if not model:
                        model = SentenceTransformer(
                            f"sentence-transformers/{self.model_name}"
                        )
                        self.GD[self.model_name] = model
                    model.to(self.device)
                    # Using sentence-transformers for sentence-level embeddings
                    embeddings = model.encode(texts)
                    # if input is a single text then sentence transformer model returns 1d numpy array by default
                    # all other models are returning 1d dimension per input sor they are 2d arrays
                    # for compatibility reason this one is converted to 2d array, too.
                    if len(embeddings.shape) == 1:
                        embeddings = embeddings.reshape(1, -1)
                else:
                    self.log.error("Unknown model type")
                    raise ValueError("Unknown model type")
        return embeddings
    
    def generate_text_embeddings_clip(self, texts):
        model = self.GD.get("image_model/" + self.model_name)
        processor = self.GD.get("image_processor/" + self.model_name)
        if not (model and processor):
            model = CLIPModel.from_pretrained(self.provider + "/" + self.model_name)
            processor = CLIPProcessor.from_pretrained(
                self.provider + "/" + self.model_name
            )
            self.GD["image_model/" + self.model_name] = model
            self.GD["image_processor/" + self.model_name] = processor
        inputs = processor(text=texts, return_tensors="pt", padding=True, truncation=True)
        embedding_values = model.get_text_features(**inputs)
        # Extract the embeddings from the last layer
        embeddings = embedding_values.cpu().detach().numpy()
        return embeddings

    @staticmethod
    def embedding_to_string(embedding: np.array) -> str:
        return "[{}]".format(", ".join(str(x) for x in embedding))
