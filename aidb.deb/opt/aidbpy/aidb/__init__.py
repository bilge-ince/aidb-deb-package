import os
import logging
import json
import plpy

import jinja2
from io import BytesIO
from PIL import Image

from aidb.generate_embeddings import TextEmbedder
from aidb.batch_processing import DataProcessor
from aidb.generate_embeddings import ImageEmbedder
from aidb.connect_s3 import S3_Connection
from aidb.retriever import Create_Retriever

from jinja2 import meta

# Define a custom logging configuration
logging_config = {
    "filename": "aidb.log",
    "filemode": "w",
    "format": "%(name)s - %(levelname)s - %(message)s",
}
logging.basicConfig(**logging_config)
# Global (per-backend) shared state managed by plpython3u extension.
GD: dict = None
batch_size = 1

pgvector_distance = {
    "cosine": {"operator_class": "vector_cosine_ops", "operator": "<=>"},
    "dot": {"operator_class": "vector_ip_ops", "operator": "<#>"},
    "euclidean": {"operator_class": "vector_l2_ops", "operator": "<->"},
}
# supported image extensions for S3
imgextentions = (".jpg", ".png", ".jpeg")

# Called at import time by aidb SQL functions.
def init(shared_state):
    global GD
    GD = shared_state


def rag(query, retriever_name, topk, template_name, envstr, model):
    # Deserialize and re-serialize the environment later
    env = {}
    if envstr:
        env = json.loads(envstr)
    env["query"] = query
    retrieved = retrieve(query, topk, retriever_name)
    env["retrieved"] = [r["data"] for r in retrieved]
    return ag(template_name, json.dumps(env), model)


# args will be JSONB - should be a dict-like object
def ag(template_name, envstr, model):
    return generate(render_prompt(template_name, envstr), model)


def generate(prompt, model):
    ## TODO
    return prompt


def render_prompt(template_name, envstr):
    env = json.loads(envstr)
    # TODO: validate that args matches env keys
    template = plpy.execute(
        """
SELECT template FROM aidb.prompt_templates WHERE name = '{template_name}'
    """.format(
            template_name=template_name
        )
    )[0]["template"]

    return jinja2.Environment().from_string(template).render(env)


def register_prompt_template(name, template):
    tmp = jinja2.Environment().from_string(template)
    parsed = tmp.environment.parse(template)
    args = meta.find_undeclared_variables(parsed)
    plpy.execute(
        """
INSERT INTO aidb.prompt_templates (name, template, args) VALUES
    ('{name}', '{template}', '{{{args}}}');
    """.format(
            name=name, template=template, args=",".join(args)
        )
    )


def get_retriever_metadata(retriever_name: str):
    retriever_data = list()
    retriever_data = plpy.execute(
        """
                SELECT r.source_schema, r.source_columns, r.source_key, r.source_table, e.provider,
                    e.name encoder_name, e.dimensions, r.embedding_table, r.distance_metric, r.s3_endpoint, r.bucket, r.prefix, r.data_type
                FROM aidb.encoders e, aidb.retrievers r
                WHERE r.name = '{retriever_name}' AND r.encoder_id = e.id;
            """.format(
            retriever_name=retriever_name
        )
    )

    if len(retriever_data) > 1:
        logging.error("Ambiguous retriever name '{}'.".format(retriever_name))
        raise ValueError("Ambiguous retriever name '{}'.".format(retriever_name))
    return retriever_data


def refresh_retriever(retriever_name: str):
    """
    This function will load all data from a source table and generate embeddings for all data
    Then populate a target table with these newly generated embeddings
    """
    file_inputs = []
    file_names = []
    # Get retriever meta data
    retriever_data = get_retriever_metadata(retriever_name)

    schema = retriever_data[0]["source_schema"]
    columns = retriever_data[0]["source_columns"]
    join_key = retriever_data[0]["source_key"]
    source_table = retriever_data[0]["source_table"]
    encoder = retriever_data[0]["encoder_name"]
    table_name = retriever_data[0]["embedding_table"]
    provider = retriever_data[0]["provider"]
    dimensions = retriever_data[0]["dimensions"]
    s3_endpoint = retriever_data[0]["s3_endpoint"]
    bucket = retriever_data[0]["bucket"]
    prefix = retriever_data[0]["prefix"]
    data_type = retriever_data[0]["data_type"]
    #
    if source_table:
        input_table_dict = plpy.execute(
            f"Select {join_key}, {columns} from {schema}.{source_table}"
        )

        # Check whether the table is populated
        if len(input_table_dict) == 0:
            logging.error("The source table is empty.")
            raise ValueError("The source table is empty.")

        # If table has already data load them wrt ids
        ids = [row[join_key] for row in input_table_dict]

        # 'columns' is a string of comma-separated column names
        column_names = columns.split(",")

        # Extracting values according to column names for each row and joining with whitespace
        inputs = [" ".join(row[col] for col in column_names) for row in input_table_dict]

        # Generate embedding for text in batches
        data_processor = DataProcessor(
            inputs, batch_size, encoder, provider, GD, dimensions
        )
        embeddings = data_processor.process_data()

        # The generated embeddings will be inserted into the table as new item
        insert_statement = "INSERT INTO {schema}.{table_name} ({join_key}, embeddings, updated_at) VALUES".format(
            schema=schema, table_name=table_name, join_key=join_key
        )
        plpy.info(f"inserted table name {schema}.{table_name}")

        for idx in range(len(embeddings)):
            embedding = TextEmbedder.embedding_to_string(embeddings[idx])
            insert_statement = insert_statement + " ({}, '{}', NOW()),".format(
                ids[idx], embedding
            )
    elif bucket:
        # assumption: single image has always a prefix that is the filename
        s3 = GD.get("s3_client")
        if not s3:
            s3 = S3_Connection(GD, s3_endpoint).create_s3_client()
            GD["s3_client"] = s3

        if data_type == "img":
            file_list = [
                f
                for f in s3.Bucket(bucket).objects.filter(Prefix=prefix if prefix else "")
                if f.key.endswith(imgextentions)
            ]
            
            # Read images from S3 and send it to the ImageEmbedder
            for file in file_list:
                file_names.append(file.key[:-4])
                try:
                    file_byte_string = file.get()["Body"].read()
                except Exception as e:
                    logging.error("Exception occurred", exc_info=True)
                    raise ValueError("Exception occurred, the object is None")

                img = Image.open(BytesIO(file_byte_string))

                if not img:
                    logging.error(
                        "Something went wrong. The input is not an image object."
                    )
                    raise ValueError("Something went wrong. The input is None.")
                file_inputs.append(img)
            # Send inputs to get embeddings
            embeddings = ImageEmbedder(encoder, provider, GD).generate_image_embeddings(
                file_inputs, file_names
            )
            insert_statement = "INSERT INTO {schema}.{table_name} ({join_key}, embeddings, updated_at) VALUES".format(
                schema=schema, table_name=table_name, join_key=join_key
            )

        # not image than a plaintext file
        elif data_type == "text":
            # get list of files that have accepted extentions

            file_list = [
                f
                for f in s3.Bucket(bucket).objects.filter(Prefix=prefix if prefix else "")
            ]

            for file in file_list:
                file_context = file.get()["Body"].read()
                # if the file type is txt decode it and add the input
                try:
                    file_inputs.append(file_context.decode(encoding="utf-8", errors="ignore"))
                except Exception as e:
                    logging.error(f"Unsupported data_type for text: {data_type}")
                    raise ValueError(f"Unsupported data_type for text: {data_type}")
                filename, _ = os.path.splitext(file.key)
                file_names.append(filename)
            data_processor = DataProcessor(
                file_inputs, batch_size, encoder, provider, GD, dimensions
            )
            embeddings = data_processor.process_data()
            insert_statement = "INSERT INTO {schema}.{table_name} ({join_key}, embeddings, updated_at) VALUES".format(
                schema=schema, table_name=table_name, join_key=join_key
            )

        # S3 bucket items have file_name as id unlike PG one (it has a numerical id instead)
        # therefore insert statement is prepared for both using file_name and wrt embedding
        else:
            logging.error(f"Unsupported data_type: {data_type}")
            raise ValueError(f"Unsupported data_type: {data_type}")
        # Concat embeddings wrt file_name as id and send it to db
        for idx in range(len(embeddings)):
            embedding = TextEmbedder.embedding_to_string(embeddings[idx])
            insert_statement = insert_statement + " ('{}', '{}', NOW()),".format(
                file_names[idx], embedding
            )
    else:
        logging.error(
            "Something went wrong! Control your parameters, either source table or S3 client don't exist!"
        )
        raise ValueError(
            "Something went wrong! Control your parameters, either source table or S3 client don't exist!"
        )
    
    conflict = """
    ON CONFLICT ({join_key})
    DO UPDATE SET embeddings = EXCLUDED.embeddings, updated_at = NOW();
        """.format(
            join_key=join_key
    )
    # [:-1] to trim off the last comma
    insert_statement = insert_statement[:-1] + conflict
    plpy.execute(insert_statement)
    return None


# TODO: pass in schema
# TODO: pass in primary key
def _embed_table_update(retriever_name, ids, inputs):
    """
    retriever_name : the name of the retriever concept for similarity search etc. e.g product embeddings
    ids : the list of ids from the table that needs embedding generation. Those ids are populated by the trigger
    inputs: text data that will be fed to embedding model
    """
    # TODO: Ensure that inputs aren't too long
    # Get retriever meta data
    retriever_data = get_retriever_metadata(retriever_name)

    schema = retriever_data[0]["source_schema"]
    join_key = retriever_data[0]["source_key"]
    encoder = retriever_data[0]["encoder_name"]
    table_name = retriever_data[0]["embedding_table"]
    provider = retriever_data[0]["provider"]
    dimensions = retriever_data[0]["dimensions"]

    # Generate embedding for text
    embedder = TextEmbedder(encoder, provider, GD, dimensions)
    embeddings = embedder.generate_text_embedding(inputs)

    insert_statement = (
        "INSERT INTO {schema}.{table_name} ({join_key}, embeddings) VALUES".format(
            schema=schema, table_name=table_name, join_key=join_key
        )
    )
    for idx in range(len(ids)):
        embedding = TextEmbedder.embedding_to_string(embeddings[idx])
        insert_statement = insert_statement + " ({}, '{}'),".format(ids[idx], embedding)

    conflict = """
ON CONFLICT ({join_key})
DO UPDATE SET embeddings = EXCLUDED.embeddings, updated_at = NOW();
    """.format(
        join_key=join_key
    )
    # [:-1] to trim off the last comma
    insert_statement = insert_statement[:-1] + conflict
    plpy.execute(insert_statement)


def retrieve(query, topk, retriever_name):
    file_inputs = []
    file_names = []
    # Get retriever meta data
    retriever_data = get_retriever_metadata(retriever_name)

    schema = retriever_data[0]["source_schema"]
    table = retriever_data[0]["source_table"]
    columns = retriever_data[0]["source_columns"]
    primary_key = retriever_data[0]["source_key"]
    encoder = retriever_data[0]["encoder_name"]
    vector_table_name = retriever_data[0]["embedding_table"]
    provider = retriever_data[0]["provider"]
    dimensions = retriever_data[0]["dimensions"]
    distance_metric = retriever_data[0]["distance_metric"]
    bucket = retriever_data[0]["bucket"]
    data_type = retriever_data[0]["data_type"]
    if table:
        # Generate embedding for the query input
        embedder = TextEmbedder(encoder, provider, GD, dimensions)
        embedding = embedder.generate_text_embedding(query)[0]
        query_embedding = TextEmbedder.embedding_to_string(embedding)
        retrieval_query = """
        SELECT ({data_expression}) AS data FROM {schema}.{table}
        WHERE {primary_key} IN (
        SELECT {primary_key} FROM {schema}.{vector_table_name}
        ORDER BY embeddings {distance_operator} '{query_vector}' LIMIT {topk});
        """.format(
            data_expression=" || ' - ' || ".join([c for c in columns.split(",")]),
            schema=schema,
            table=table,
            vector_table_name=vector_table_name,
            primary_key=primary_key,
            distance_operator=pgvector_distance[distance_metric]["operator"],
            query_vector=query_embedding,
            topk=topk,
        )
    # If it's a query search but in s3 object embeddings tables
    elif bucket:
        if data_type == "text":
            embedder = TextEmbedder(encoder, provider, GD, dimensions)
            embedding = embedder.generate_text_embedding(query)[0]
            query_embedding = TextEmbedder.embedding_to_string(embedding)

            retrieval_query = """
            SELECT {primary_key} FROM {schema}.{vector_table_name}
            ORDER BY embeddings {distance_operator} '{query_vector}' LIMIT {topk};
            """.format(
                schema=schema,
                vector_table_name=vector_table_name,
                primary_key=primary_key,
                distance_operator=pgvector_distance[distance_metric]["operator"],
                query_vector=query_embedding,
                topk=topk,
            )
        elif data_type == "img":
            embedder = TextEmbedder(encoder, provider, GD, dimensions)
            embedding = embedder.generate_text_embeddings_clip(query)[0]
            query_embedding = TextEmbedder.embedding_to_string(embedding)
            retrieval_query = """
            SELECT {primary_key} FROM {schema}.{vector_table_name}
            ORDER BY embeddings {distance_operator} '{query_vector}' LIMIT {topk};
            """.format(
                schema=schema,
                vector_table_name=vector_table_name,
                primary_key=primary_key,
                distance_operator=pgvector_distance[distance_metric]["operator"],
                query_vector=query_embedding,
                topk=topk,
            )
        else:
            logging.error("Something went wrong! Check your data_type and query.")
            raise ValueError("Something went wrong! Check your data_type and query")
    else:
        logging.error(
            "Something went wrong! Control your parameters. Table or endpoint doesn't exist."
        )
        raise ValueError(
            "Something went wrong! Control your parameters.Table or endpoint doesn't exist."
        )

    return plpy.execute(retrieval_query)


def retrieve_via_s3(retriever_name, topk, s3_endpoint, bucket, object):
    file_inputs = []
    file_names = []
    # Get retriever meta data
    retriever_data = get_retriever_metadata(retriever_name)

    schema = retriever_data[0]["source_schema"]
    primary_key = retriever_data[0]["source_key"]
    encoder = retriever_data[0]["encoder_name"]
    vector_table_name = retriever_data[0]["embedding_table"]
    provider = retriever_data[0]["provider"]
    dimensions = retriever_data[0]["dimensions"]
    distance_metric = retriever_data[0]["distance_metric"]
    data_type = retriever_data[0]["data_type"]
    if bucket:
        # assumption: single image has always a prefix that is the filename
        s3 = GD.get("s3_client")
        if not s3:
            s3 = S3_Connection(GD, s3_endpoint).create_s3_client()
            GD["s3_client"] = s3

        if data_type == "img":
            img_embedding = ImageEmbedder(
                encoder, provider, GD, s3_endpoint, bucket, object
            ).generate_single_image_embedding()[0]
            query_embedding = TextEmbedder.embedding_to_string(img_embedding)
            retrieval_query = """
            SELECT {primary_key} FROM {schema}.{vector_table_name}
            ORDER BY embeddings {distance_operator} '{query_vector}' LIMIT {topk};
            """.format(
                schema=schema,
                vector_table_name=vector_table_name,
                primary_key=primary_key,
                distance_operator=pgvector_distance[distance_metric]["operator"],
                query_vector=query_embedding,
                topk=topk,
            )

        # not image than a plaintext file
        elif data_type == "text":
            # Generate embedding for the query input
            # query = None
            query_text = (
                s3.Object(bucket, object)
                .get()["Body"]
                .read()
                .decode(encoding="utf-8", errors="ignore")
            )
            embedder = TextEmbedder(encoder, provider, GD, dimensions)
            embedding = embedder.generate_text_embedding(query_text)[0]
            query_embedding = TextEmbedder.embedding_to_string(embedding)

            retrieval_query = """
            SELECT {primary_key} FROM {schema}.{vector_table_name}
            ORDER BY embeddings {distance_operator} '{query_vector}' LIMIT {topk};
            """.format(
                schema=schema,
                vector_table_name=vector_table_name,
                primary_key=primary_key,
                distance_operator=pgvector_distance[distance_metric]["operator"],
                query_vector=query_embedding,
                topk=topk,
            )
    else:
        logging.error(
            "Something went wrong! Control your parameters, either source table or S3 client don't exist!"
        )
        raise ValueError(
            "Something went wrong! Control your parameters, either source table or S3 client don't exist!"
        )
    return plpy.execute(retrieval_query)
