# aidb

`aidb` is a Postgres extension that relies on PL/Python and on `pgvector` extension.
It introduces the concept of a `retriever` in Postgres that automatically handles generation of vector embeddings for AI data and provides methods to search and retrieve the AI data based on similarity to a provided search query.

`aidb` supports to run OpenAI and HuggingFace embedding models. The prior requires the user to configure his OpenAI API key.
The latter is run locally with PL/Python.

This repository uses a docker container to build and test the `aidb` extension.

The extension is defined in `aidb--0.0.2.sql`. It consists of a set of functions and meta tables. The business logic of the functions is in `aidb/__init__.py`.

## Requirements
- Set the `PGPASSWORD` environment variable to a password for the postgres database.
- (Optional) If using the `S3 bucket retriever` feature, set the `SECRET_KEY` and `ACCESS_KEY` environment variables with your AWS S3 credentials. These are only necessary for private S3 buckets; skip this if the bucket is public. 
- (Optional) If an OPENAI model will be used, set the `OPENAI_API_KEY` environment variable to your OpenAI API key.

## Demo Usage

`make demo` runs `aidb_demo.sql` to demonstrate the key functions

You can use the `aidb_demo.sql` demo script to get a walk through of the general workings. The core functions are:

- `create_pg_retriever()` and  `create_s3_retriever()` This configures a retriever setup for a certain set of source AI data. It creates a table for the embeddings and functions and triggers to keep these up to date with any new source data records.
- `refresh_retriever()` This refreshes embeddings from all source data for a given retriever.
- `retrieve()` and `retrieve_via_s3()` These two functions conduct a similarity search for a given query and returns the Top K matching AI data records.

## Usage

1. `make build` builds the things
2. `make run` starts the container
3. `make regress` runs a regression test per `test/sql/test.sql`
   - Edit the `test/sql/test.sql` file to configure the model and other behavior
   - `make save_regress` Saves the current regression test output of `test/sql/test.sql` as the new baseline for further tests
4. `make psql` drops you into a `psql` interactive command line
5. `make stop` stops and deletes the container.
6. `make test` runs the sequence of `stop`, `build`, `run` and `test` for convenience

For more details and example usage, visit the [EDB Webpage](https://www.enterprisedb.com/docs/edb-postgres-ai/ai-ml/using-tech-preview/).
