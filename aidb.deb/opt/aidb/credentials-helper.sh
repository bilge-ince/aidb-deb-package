#!/usr/bin/env bash

echo "--------------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------------"
echo "Welcome to the EDB AIDB tech-preview credentials helper"
echo "Copy/Paste the credentials when prompted"
echo "Don’t add Access key and Secret key if you want to use a public bucket"
echo "otherwise add them."
echo "To re-run, execute ./opt/aidb/credentials-helper.sh"
echo "--------------------------------------------------------------------------------"
echo "--------------------------------------------------------------------------------"

read -p "OpenAI API Key: " OPENAI_API_KEY
read -p "AWS S3 Access Key: " ACCESS_KEY
read -p "AWS S3 Secret Access Key: " SECRET_KEY

sed -i -e "s/@OPENAI_API_KEY@/${OPENAI_API_KEY}/g" /etc/postgresql/16/main/environment
sed -i -e "s/@ACCESS_KEY@/${ACCESS_KEY}/g" /etc/postgresql/16/main/environment
sed -i -e "s/@SECRET_KEY@/${SECRET_KEY}/g" /etc/postgresql/16/main/environment

# PG needs to be restarted to pick up the new env vars
service postgresql restart